import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Droplets, Hourglass, Sparkles, Ban } from "lucide-react";
import SectionHead from "./SectionHead";

const CHANGES = ["Вертикальные зрачки", "Бледная кожа", "Новый цвет волос", "Узоры на теле"];

export default function Transformation() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-12%", "12%"]);

  return (
    <section className="relative py-24 md:py-40 overflow-hidden">
      {/* bg image parallax */}
      <div ref={ref} className="absolute inset-0">
        <motion.img
          style={{ y, scale: 1.25 }}
          src="/images/transformation.jpg"
          alt="Обращение в демона"
          className="w-full h-full object-cover img-tint opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-void via-void/70 to-void" />
      </div>

      <div className="relative mx-auto max-w-[1300px] px-5 md:px-10">
        <SectionHead
          index="04"
          kanji="変"
          title="Обращение в демона"
          sub="Человек умирает. Рождается нечто иное."
        />

        <div className="grid lg:grid-cols-2 gap-6 md:gap-10">
          {/* rebirth */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="relative overflow-hidden rounded-2xl border border-blood/30 bg-void/70 backdrop-blur-md p-7 md:p-10"
          >
            <Droplets className="size-7 text-blood mb-6" />
            <h3 className="font-display text-xl md:text-2xl font-bold uppercase text-bone leading-snug">
              Перевоплощение
            </h3>
            <p className="mt-4 font-sans text-sm md:text-base leading-relaxed text-bone/75">
              Чтобы обычный человек стал демоном, он должен принять{" "}
              <span className="text-ember font-semibold">большое количество демонической
              крови</span> — и выжить. Перевоплощение сопровождается ужасной
              болью, после которой прежний облик изменяется навсегда.
            </p>

            <div className="mt-7">
              <p className="flex items-center gap-2 font-sans text-[11px] uppercase tracking-[0.3em] text-ash mb-4">
                <Sparkles className="size-4 text-blood" />
                Метки новой плоти
              </p>
              <div className="flex flex-wrap gap-2.5">
                {CHANGES.map((c, i) => (
                  <motion.span
                    key={c}
                    initial={{ opacity: 0, scale: 0.85 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.15 + i * 0.08, duration: 0.45 }}
                    className="rounded-full border border-blood/40 bg-blood/10 px-4 py-2 font-sans text-xs md:text-sm text-bone/85"
                  >
                    {c}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* probation */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ delay: 0.12, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="relative overflow-hidden rounded-2xl border border-bone/15 bg-void/70 backdrop-blur-md p-7 md:p-10 flex flex-col"
          >
            <Hourglass className="size-7 text-bone/70 mb-6" />
            <h3 className="font-display text-xl md:text-2xl font-bold uppercase text-bone leading-snug">
              Испытательный срок
            </h3>
            <p className="mt-4 font-sans text-sm md:text-base leading-relaxed text-bone/75">
              Каждый новообращённый несёт испытательный срок, который
              ограничивает его место во фракции:
            </p>

            <ul className="mt-6 space-y-3">
              {[
                "Нельзя вступать в отряды",
                "Нельзя повышать ранг",
              ].map((t) => (
                <li key={t} className="flex items-center gap-3 font-sans text-sm md:text-base text-bone/75">
                  <Ban className="size-4 shrink-0 text-blood" />
                  {t}
                </li>
              ))}
            </ul>

            <div className="mt-auto pt-8">
              <div className="rounded-xl border border-blood/40 bg-gradient-to-r from-blood/20 to-transparent p-5">
                <p className="font-sans text-[11px] uppercase tracking-[0.3em] text-blood mb-2">
                  Путь снятия
                </p>
                <p className="font-serif italic text-lg md:text-xl text-bone">
                  Испытание «Возвышение крови» — единственный способ сбросить
                  цепи испытательного срока.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
