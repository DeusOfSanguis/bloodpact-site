import { useEffect, useState } from "react";
import { motion } from "framer-motion";

export default function Preloader({ onDone }: { onDone: () => void }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const start = performance.now();
    const dur = 1900;
    let raf: number;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      setCount(Math.round(p * 100));
      if (p < 1) raf = requestAnimationFrame(tick);
      else setTimeout(onDone, 420);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-void"
      exit={{ y: "-100%", transition: { duration: 0.9, ease: [0.76, 0, 0.24, 1] } }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.6, filter: "blur(12px)" }}
        animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
        transition={{ duration: 1.1, ease: "easeOut" }}
        className="relative"
      >
        <span
          className="font-display text-[26vw] md:text-[15rem] font-black leading-none text-blood select-none"
          style={{ textShadow: "0 0 120px rgba(211,19,42,.65)" }}
        >
          血
        </span>
        <motion.span
          className="absolute inset-0 font-display text-[26vw] md:text-[15rem] font-black leading-none text-ember select-none mix-blend-screen"
          animate={{ opacity: [0, 0.7, 0], x: [0, 4, -3, 0] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: "linear" }}
        >
          血
        </motion.span>
      </motion.div>

      <div className="mt-10 w-56 md:w-72">
        <div className="flex items-baseline justify-between font-sans text-[11px] tracking-[0.35em] text-ash uppercase mb-3">
          <span>Пробуждение</span>
          <span className="text-bone tabular-nums">{count}%</span>
        </div>
        <div className="h-px w-full bg-bone/10 overflow-hidden">
          <motion.div
            className="h-full bg-blood origin-left"
            style={{ scaleX: count / 100 }}
          />
        </div>
      </div>

      <span className="absolute bottom-8 font-serif italic text-ash text-sm tracking-wide">
        кровь помнит всё
      </span>
    </motion.div>
  );
}
