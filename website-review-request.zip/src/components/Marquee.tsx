const ITEMS = ["КРОВЬ", "血", "ЛУНА", "月", "ВЕЧНОСТЬ", "鬼", "ПАКТ", "約", "ТЬМА", "闇", "СИЛА", "力"];

export default function Marquee({ reverse = false }: { reverse?: boolean }) {
  const row = (key: string) => (
    <div key={key} className="flex shrink-0 items-center">
      {ITEMS.map((it, i) => (
        <span key={i} className="flex items-center">
          <span
            className={`mx-6 md:mx-10 font-display text-2xl md:text-4xl font-bold tracking-widest select-none ${
              /[\u4e00-\u9fff]/.test(it) ? "text-blood/80" : "text-bone/60"
            }`}
          >
            {it}
          </span>
          <span className="size-1.5 rounded-full bg-blood/70" />
        </span>
      ))}
    </div>
  );

  return (
    <div className="relative overflow-hidden border-y border-blood/15 bg-coal/60 py-5 md:py-6">
      <div
        className="flex w-max animate-marquee"
        style={reverse ? { animationDirection: "reverse" } : undefined}
      >
        {row("a")}
        {row("b")}
      </div>
    </div>
  );
}
