import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Moon, RefreshCw, Zap, Crown } from "lucide-react";
import SectionHead from "./SectionHead";

const TRAITS = [
  {
    icon: Moon,
    title: "Дитя ночи",
    text: "Солнечный свет смертелен — он сожжёт демона дотла. Вся активность фракции существует исключительно под покровом темноты.",
  },
  {
    icon: RefreshCw,
    title: "Регенерация",
    text: "Любая рана затягивается мгновенно: демон способен заново отрастить даже голову. Обычное оружие для него — ничто.",
  },
  {
    icon: Zap,
    title: "Аномальная сила",
    text: "Физические характеристики демонов далеко за пределами человеческих. Сила растёт с каждой поглощённой жизнью.",
  },
  {
    icon: Crown,
    title: "Воля Прародителя",
    text: "Каждая капля демонической крови связывает демона с Прародителем — его слово абсолютно, его проклятье вечно.",
  },
];

export default function About() {
  const imgRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: imgRef, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-8%", "8%"]);

  return (
    <section id="faction" className="relative px-5 md:px-10 py-24 md:py-40">
      <div className="mx-auto max-w-[1500px]">
        <SectionHead
          index="01"
          kanji="鬼"
          title="Кто такие демоны"
          sub="Плотоядный вампирический вид, чьей основной пищей являются люди."
        />

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* portrait */}
          <motion.div
            initial={{ opacity: 0, clipPath: "inset(12% 12% 12% 12%)" }}
            whileInView={{ opacity: 1, clipPath: "inset(0% 0% 0% 0%)" }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
            className="relative lg:sticky lg:top-28"
          >
            <div ref={imgRef} className="relative overflow-hidden rounded-2xl border border-blood/25 blood-glow">
              <motion.img
                style={{ y, scale: 1.18 }}
                src="/images/progenitor.jpg"
                alt="Прародитель демонов"
                className="w-full h-[420px] md:h-[600px] object-cover object-top img-tint"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-void via-transparent to-transparent" />
              <div className="absolute bottom-0 inset-x-0 p-6 md:p-8">
                <p className="font-sans text-[10px] uppercase tracking-[0.4em] text-blood mb-2">
                  Наш Господин
                </p>
                <p className="font-display text-xl md:text-2xl font-bold text-bone">
                  Прародитель демонов
                </p>
                <p className="mt-2 font-serif italic text-sm text-bone/60 max-w-sm">
                  Имя его нельзя произнести — проклятье крови карает мучительной
                  смертью каждого, кто попытается.
                </p>
              </div>
            </div>

            <motion.span
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute -top-5 -right-4 md:-right-6 grid place-items-center size-16 md:size-20 rounded-full border border-blood/40 bg-void font-display text-3xl md:text-4xl text-blood blood-glow select-none"
            >
              血
            </motion.span>
          </motion.div>

          {/* traits */}
          <div className="flex flex-col gap-4">
            {TRAITS.map((t, i) => (
              <motion.div
                key={t.title}
                initial={{ opacity: 0, y: 36 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ delay: i * 0.08, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                className="group relative overflow-hidden rounded-xl border border-bone/10 bg-coal/60 p-6 md:p-8 transition-colors duration-500 hover:border-blood/50"
              >
                <span className="absolute -right-4 -bottom-6 font-display font-black text-7xl text-bone/[0.04] group-hover:text-blood/10 transition-colors duration-500 select-none">
                  0{i + 1}
                </span>
                <div className="flex items-start gap-5">
                  <span className="mt-1 grid place-items-center size-11 shrink-0 rounded-full border border-blood/40 bg-blood/10 text-blood group-hover:bg-blood group-hover:text-bone transition-colors duration-500">
                    <t.icon className="size-5" />
                  </span>
                  <div>
                    <h3 className="font-display text-base md:text-lg font-bold text-bone uppercase tracking-wide">
                      {t.title}
                    </h3>
                    <p className="mt-2 font-sans text-sm md:text-[15px] leading-relaxed text-ash">
                      {t.text}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}

            <motion.blockquote
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 1 }}
              className="mt-4 border-l-2 border-blood pl-6 py-2"
            >
              <p className="font-serif italic text-xl md:text-2xl text-bone/85 leading-snug">
                «Человек умирает один раз. Демон — никогда. В этом и есть наша
                вечность».
              </p>
            </motion.blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
