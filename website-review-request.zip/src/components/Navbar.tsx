import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Droplet } from "lucide-react";

const LINKS = [
  { href: "#faction", label: "Фракция" },
  { href: "#laws", label: "Законы" },
  { href: "#moons", label: "Луны" },
  { href: "#hierarchy", label: "Иерархия" },
  { href: "#privileges", label: "Привилегии" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className={`fixed top-0 inset-x-0 z-[80] transition-all duration-500 ${
          scrolled
            ? "bg-void/70 backdrop-blur-xl border-b border-blood/15 py-3"
            : "bg-transparent py-5"
        }`}
      >
        <div className="mx-auto max-w-[1500px] px-5 md:px-10 flex items-center justify-between">
          <a href="#top" className="group flex items-center gap-3">
            <span className="grid place-items-center size-9 rounded-full border border-blood/40 bg-blood/10 blood-glow">
              <Droplet className="size-4 text-blood group-hover:scale-125 transition-transform duration-300" />
            </span>
            <span className="font-display text-sm md:text-base tracking-[0.2em] text-bone font-bold">
              ПАКТ<span className="text-blood">·</span>КРОВИ
            </span>
          </a>

          <nav className="hidden md:flex items-center gap-8">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="relative font-sans text-[12px] uppercase tracking-[0.28em] text-ash hover:text-bone transition-colors duration-300 after:absolute after:-bottom-1 after:left-0 after:h-px after:w-0 after:bg-blood after:transition-all after:duration-300 hover:after:w-full"
              >
                {l.label}
              </a>
            ))}
            <a
              href="#privileges"
              className="ml-2 rounded-full border border-blood/50 bg-blood/10 px-5 py-2 text-[11px] uppercase tracking-[0.25em] text-bone hover:bg-blood hover:shadow-[0_0_30px_-5px_rgba(211,19,42,.8)] transition-all duration-300"
            >
              Вступить
            </a>
          </nav>

          <button
            onClick={() => setOpen(true)}
            className="md:hidden text-bone"
            aria-label="Меню"
          >
            <Menu className="size-6" />
          </button>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[95] bg-void/95 backdrop-blur-2xl flex flex-col"
          >
            <div className="flex justify-end p-6">
              <button onClick={() => setOpen(false)} aria-label="Закрыть">
                <X className="size-7 text-bone" />
              </button>
            </div>
            <nav className="flex-1 flex flex-col items-center justify-center gap-6">
              {LINKS.map((l, i) => (
                <motion.a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  initial={{ y: 30, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.08 * i, duration: 0.5 }}
                  className="font-display text-3xl font-bold text-bone hover:text-blood transition-colors"
                >
                  {l.label}
                </motion.a>
              ))}
            </nav>
            <span className="pb-10 text-center font-serif italic text-ash">
              鬼 · кровь · честь
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
