import { motion } from "framer-motion";
import { Droplet, ArrowUp } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative border-t border-blood/15 bg-coal/40 overflow-hidden">
      <div className="pointer-events-none absolute bottom-0 left-1/2 -translate-x-1/2 size-[600px] rounded-full bg-blood/10 blur-[140px]" />

      <div className="relative mx-auto max-w-[1500px] px-5 md:px-10 pt-16 md:pt-24 pb-10">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-10">
          <div>
            <p className="font-sans text-[11px] uppercase tracking-[0.4em] text-ash mb-4">
              YUFU · Фракция демонов
            </p>
            <motion.h2
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              className="font-display font-black uppercase leading-[0.95] text-[13vw] md:text-8xl"
            >
              <span className="text-stroke-bone">Пакт</span>{" "}
              <span className="text-blood" style={{ textShadow: "0 0 70px rgba(211,19,42,.6)" }}>
                Крови
              </span>
            </motion.h2>
            <p className="mt-5 max-w-md font-serif italic text-base md:text-lg text-ash">
              Кровь, что связывает нас, сильнее смерти. Ночь наша — и она
              будет длиться вечно.
            </p>
          </div>

          <div className="flex flex-col items-start md:items-end gap-6">
            <a
              href="#top"
              className="group flex items-center gap-3 rounded-full border border-blood/40 bg-blood/10 px-6 py-3 font-sans text-[11px] uppercase tracking-[0.3em] text-bone hover:bg-blood transition-colors duration-300"
            >
              <ArrowUp className="size-4 group-hover:-translate-y-1 transition-transform duration-300" />
              Вернуться во тьму
            </a>
            <div className="flex items-center gap-2 text-ash">
              <Droplet className="size-4 text-blood" />
              <span className="font-sans text-xs tracking-[0.25em] uppercase">
                鬼 · 血 · 月
              </span>
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-t border-bone/10 pt-6">
          <p className="font-sans text-xs text-ash/70">
            © {new Date().getFullYear()} Пакт Крови · YUFU. Все права принадлежат ночи.
          </p>
          <p className="font-sans text-xs text-ash/50">
            Создано по мотивам вселенной «Клинок, рассекающий демонов»
          </p>
        </div>
      </div>
    </footer>
  );
}
