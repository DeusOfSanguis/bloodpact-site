import { useRef } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { Crown, Gem, Castle, Users, ChevronRight } from "lucide-react";
import SectionHead from "./SectionHead";

type Node = {
  label: string;
  sub?: string;
  icon?: typeof Crown;
  major?: boolean;
};

const NODES: Node[] = [
  { label: "Прародитель демонов", sub: "Абсолютная власть", icon: Crown, major: true },
  { label: "Высшие луны", sub: "Полное командование нижестоящими", icon: Gem, major: true },
  { label: "Низшие луны", sub: "Вторичное командование", icon: Castle, major: true },
  { label: "Владельцы отрядов", icon: Users },
  { label: "5 RIM" },
  { label: "VIC" },
  { label: "3–4 RIM" },
  { label: "Инструктор" },
  { label: "1–2 RIM" },
  { label: "D.CMD и CMD отрядов" },
  { label: "Первые двенадцать рангов", major: true },
];

const RANKS_12 = [
  "Отокума", "Демон", "Кейкона", "Хофума", "Чисума", "Чикума",
  "Асакума", "Хобура", "Шатэигасира", "Вакагасира", "Цукомон", "Шико",
];

export default function Hierarchy() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.75", "end 0.55"],
  });
  const line = useSpring(scrollYProgress, { stiffness: 60, damping: 20 });

  return (
    <section id="hierarchy" className="relative px-5 md:px-10 py-24 md:py-40 bg-coal/30">
      <div className="mx-auto max-w-[1300px]">
        <SectionHead
          index="05"
          kanji="階"
          title="Иерархия фракции"
          sub="Лестница подчинения — от Прародителя до первых двенадцати рангов. Каждая ступень абсолютна для той, что ниже."
        />

        <div ref={ref} className="relative max-w-3xl">
          {/* scroll line */}
          <div className="absolute left-[14px] md:left-[18px] top-0 bottom-0 w-px bg-bone/10">
            <motion.div
              style={{ scaleY: line }}
              className="h-full w-full origin-top bg-gradient-to-b from-blood via-ember to-blood-deep"
            />
          </div>

          <div className="space-y-5 md:space-y-6">
            {NODES.map((n, i) => (
              <motion.div
                key={n.label}
                initial={{ opacity: 0, x: -32 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                className="relative flex items-start gap-5 md:gap-7 pl-0"
              >
                <span
                  className={`relative z-10 grid place-items-center shrink-0 rounded-full border ${
                    n.major
                      ? "size-[30px] md:size-[38px] border-blood bg-blood/20 text-blood blood-glow"
                      : "size-[30px] md:size-[38px] border-bone/25 bg-void text-ash"
                  }`}
                >
                  {n.icon ? (
                    <n.icon className="size-3.5 md:size-4" />
                  ) : (
                    <span className="size-1.5 rounded-full bg-current" />
                  )}
                </span>

                <div
                  className={`flex-1 rounded-xl border px-5 py-4 md:px-7 md:py-5 transition-colors duration-300 ${
                    n.major
                      ? "border-blood/40 bg-blood/10 hover:border-blood"
                      : "border-bone/10 bg-void/60 hover:border-bone/30"
                  }`}
                >
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p
                        className={`font-display font-bold uppercase tracking-wide ${
                          n.major ? "text-base md:text-xl text-bone" : "text-sm md:text-lg text-bone/75"
                        }`}
                      >
                        {n.label}
                      </p>
                      {n.sub && (
                        <p className="mt-1 font-serif italic text-xs md:text-sm text-ash">
                          {n.sub}
                        </p>
                      )}
                    </div>
                    <span className="font-sans text-[10px] uppercase tracking-[0.3em] text-ash/60 tabular-nums">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                  </div>

                  {n.label === "Первые двенадцать рангов" && (
                    <div className="mt-5 flex flex-wrap gap-2">
                      {RANKS_12.map((r, j) => (
                        <span
                          key={r}
                          className="flex items-center gap-1.5 rounded-full border border-bone/15 bg-void/80 px-3 py-1.5 font-sans text-[11px] md:text-xs text-bone/70"
                        >
                          <span className="tabular-nums text-blood/80">{j + 1}</span>
                          <ChevronRight className="size-3 text-blood/50" />
                          {r}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9 }}
          className="mt-12 max-w-2xl font-sans text-sm md:text-base leading-relaxed text-ash border-l-2 border-blood/50 pl-5"
        >
          Демоны первых двенадцати рангов могут осуществлять мелкое руководство
          нижестоящими — «принеси, подай, не стой на пути». Все, кто стоит
          выше, вправе организовывать сборы нижестоящих демонов на мероприятия.
        </motion.p>
      </div>
    </section>
  );
}
