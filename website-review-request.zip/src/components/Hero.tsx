import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ChevronDown, MoonStar } from "lucide-react";

const TITLE_1 = "ПАКТ";
const TITLE_2 = "КРОВИ";

function SplitWord({ word, delay, red }: { word: string; delay: number; red?: boolean }) {
  return (
    <span className="inline-flex overflow-hidden pb-[0.08em] -mb-[0.08em]">
      {word.split("").map((ch, i) => (
        <motion.span
          key={i}
          initial={{ y: "115%", rotate: 6 }}
          animate={{ y: "0%", rotate: 0 }}
          transition={{ delay: delay + i * 0.055, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className={`inline-block font-display font-black leading-[0.95] tracking-tight ${
            red ? "text-blood" : "text-bone"
          }`}
          style={
            red
              ? { textShadow: "0 0 90px rgba(211,19,42,.75)" }
              : { textShadow: "0 0 60px rgba(0,0,0,.6)" }
          }
        >
          {ch}
        </motion.span>
      ))}
    </span>
  );
}

export default function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "22%"]);
  const bgScale = useTransform(scrollYProgress, [0, 1], [1.05, 1.22]);
  const fade = useTransform(scrollYProgress, [0, 0.75], [1, 0]);
  const titleY = useTransform(scrollYProgress, [0, 1], ["0%", "60%"]);

  return (
    <section ref={ref} id="top" className="relative h-[108svh] overflow-hidden">
      {/* background */}
      <motion.div style={{ y: bgY, scale: bgScale }} className="absolute inset-0">
        <img
          src="/images/blood-moon.jpg"
          alt="Кровавая луна"
          className="w-full h-full object-cover img-tint"
        />
      </motion.div>
      <div className="absolute inset-0 bg-gradient-to-b from-void/70 via-transparent to-void" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,rgba(6,3,9,0.75)_100%)]" />

      {/* vertical kanji */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 1.4 }}
        className="absolute right-5 md:right-12 top-1/2 -translate-y-1/2 hidden sm:flex flex-col items-center gap-6"
      >
        <span className="vertical-rl font-display text-2xl md:text-4xl font-bold text-bone/25 tracking-[0.5em] select-none">
          鬼ノ契約
        </span>
        <span className="h-24 w-px bg-gradient-to-b from-blood/70 to-transparent" />
        <span className="vertical-rl font-serif italic text-blood/80 text-lg tracking-widest">
          клятва демона
        </span>
      </motion.div>

      {/* content */}
      <motion.div
        style={{ opacity: fade, y: titleY }}
        className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4"
      >
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55, duration: 0.8 }}
          className="mb-8 flex items-center gap-4"
        >
          <span className="h-px w-10 md:w-20 bg-blood/60" />
          <span className="flex items-center gap-2 font-sans text-[11px] md:text-xs uppercase tracking-[0.45em] text-bone/80">
            <MoonStar className="size-4 text-blood" />
            YUFU · Фракция демонов
          </span>
          <span className="h-px w-10 md:w-20 bg-blood/60" />
        </motion.div>

        <h1 className="flex flex-col items-center text-[19vw] md:text-[11.5rem] leading-[0.9]">
          <SplitWord word={TITLE_1} delay={0.7} />
          <SplitWord word={TITLE_2} delay={1.0} red />
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.7, duration: 0.9 }}
          className="mt-8 max-w-md md:max-w-xl font-serif italic text-base md:text-xl text-bone/70 leading-relaxed"
        >
          «Мы — те, кто правит ночью. Солнце сжигает нас, но не клятву,
          скреплённую кровью Прародителя».
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.2, duration: 1 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href="#faction"
            className="group relative overflow-hidden rounded-full bg-blood px-8 py-3.5 font-sans text-[12px] uppercase tracking-[0.3em] text-bone blood-glow transition-transform duration-300 hover:scale-105"
          >
            <span className="relative z-10">Познать тьму</span>
            <span className="absolute inset-0 bg-blood-deep translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
          </a>
          <a
            href="#hierarchy"
            className="rounded-full border border-bone/25 px-8 py-3.5 font-sans text-[12px] uppercase tracking-[0.3em] text-bone/80 hover:border-blood hover:text-bone transition-colors duration-300"
          >
            Иерархия
          </a>
        </motion.div>
      </motion.div>

      {/* scroll cue */}
      <motion.div
        style={{ opacity: fade }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10"
      >
        <span className="font-sans text-[10px] uppercase tracking-[0.4em] text-ash">
          Склонись ниже
        </span>
        <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 1.6, repeat: Infinity }}>
          <ChevronDown className="size-5 text-blood" />
        </motion.div>
      </motion.div>
    </section>
  );
}
