import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, X, Info, ShieldAlert } from "lucide-react";
import SectionHead from "./SectionHead";

type Role = {
  id: string;
  name: string;
  kanji: string;
  allowed: string[];
  forbidden: string[];
  note?: string;
};

const BASE_FORBIDDEN = [
  "Неподчинение установленной иерархии",
  "Нарушение демонических законов",
  "Вредительство фракции",
  "Выдача прав, рангов и привилегий без одобрения Прародителя — «блат»",
  "Невыполнение прямых обязанностей",
];

const ROLES: Role[] = [
  {
    id: "progenitor",
    name: "Прародитель демонов",
    kanji: "王",
    allowed: ["Осуществлять полное командование над фракцией демонов"],
    forbidden: ["Лениться и вредить фракции"],
    note: "Его слово — абсолют. Его имя нельзя произносить вслух.",
  },
  {
    id: "upper",
    name: "Высшие луны",
    kanji: "上",
    allowed: [
      "Полное командование над нижестоящими демонами",
      "Организация сборов на мероприятия: тренировки, вылазки и т.п.",
      "Пресекать нарушения демонических законов",
      "Свободное посещение запретных территорий (кроме Зала Прародителя)",
      "Полное командование отрядом, если луна — его смотрящая",
      "Обучать диких демонов и обращать скитальцев",
    ],
    forbidden: BASE_FORBIDDEN,
    note: "При мероприятиях отряда высшая луна имеет приоритетное право командования его составом. Злоупотребление карается снятием привилегий.",
  },
  {
    id: "lower",
    name: "Низшие луны",
    kanji: "下",
    allowed: [
      "Полное командование над нижестоящими демонами",
      "Организация сборов нижестоящих на мероприятия",
      "Пресекать нарушения демонических законов",
      "Свободное посещение запретных территорий (кроме Зала Прародителя, Зала высших лун и Горы Натагумо)",
      "Вторичное командование отрядом, если луна — его смотрящая",
      "Обучать диких демонов и обращать скитальцев",
    ],
    forbidden: BASE_FORBIDDEN,
    note: "Все обновления и деятельность низшей луны для отряда должны быть одобрены высшей луной.",
  },
  {
    id: "owners",
    name: "Владельцы отрядов",
    kanji: "隊",
    allowed: [
      "Руководить нижестоящими демонами",
      "Организовывать сборы на мероприятия",
      "Запрашивать выговор",
      "Полное командование своим отрядом",
      "Обучать диких демонов и обращать скитальцев",
    ],
    forbidden: [...BASE_FORBIDDEN, "Пропуск сборов низших лун и выше"],
    note: "Донатные отряды — боевые единицы под полным контролем владельца, но в рамках демонических законов.",
  },
  {
    id: "instructor",
    name: "Инструктор",
    kanji: "教",
    allowed: [
      "Руководить нижестоящими демонами",
      "Организовывать сборы на мероприятия",
      "Запрашивать выговор",
      "Пресекать нарушения",
      "Обучать диких демонов и обращать скитальцев",
    ],
    forbidden: BASE_FORBIDDEN,
    note: "Во время тренировок приказы инструктора приоритетнее приказов владельцев отрядов. При пресечении наказания — на уровень выше владельца отряда.",
  },
  {
    id: "cerber",
    name: "Полумесяц / Цербер",
    kanji: "牙",
    allowed: [
      "Руководить нижестоящими демонами",
      "Запрашивать выговоры",
      "Пресекать нарушения",
      "Обучать диких демонов и обращать скитальцев",
    ],
    forbidden: BASE_FORBIDDEN,
    note: "При пресечении наказания становится на уровень выше владельца донатного отряда.",
  },
];

const SQUAD = [
  { rank: "Высшая луна", desc: "Полная власть над отрядом" },
  { rank: "Низшая луна", desc: "Вторичное командование — изменения согласуются с высшей луной" },
  { rank: "КМД", desc: "Тренировки состава, проверка шрамов, дисциплина" },
  { rank: "Зам. КМД", desc: "Помощь КМД в выполнении обязанностей" },
];

export default function Privileges() {
  const [active, setActive] = useState(ROLES[1].id);
  const role = ROLES.find((r) => r.id === active)!;

  return (
    <section id="privileges" className="relative px-5 md:px-10 py-24 md:py-40 overflow-hidden">
      <div className="pointer-events-none absolute -top-40 right-0 size-[700px] rounded-full bg-blood/8 blur-[160px]" />

      <div className="relative mx-auto max-w-[1300px]">
        <SectionHead
          index="06"
          kanji="権"
          title="Привилегии должностей"
          sub="Что дозволено тому, кто несёт власть — и за что падёт даже луна."
        />

        <div className="grid lg:grid-cols-[300px_1fr] gap-8 lg:gap-14">
          {/* role selector */}
          <div className="flex lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0 -mx-5 px-5 lg:mx-0 lg:px-0">
            {ROLES.map((r) => {
              const isActive = r.id === active;
              return (
                <button
                  key={r.id}
                  onClick={() => setActive(r.id)}
                  className={`group relative flex shrink-0 items-center gap-4 rounded-xl border px-5 py-4 text-left transition-all duration-300 ${
                    isActive
                      ? "border-blood bg-blood/15 blood-glow"
                      : "border-bone/10 bg-void/50 hover:border-blood/40"
                  }`}
                >
                  <span
                    className={`font-display text-xl font-bold transition-colors duration-300 ${
                      isActive ? "text-blood" : "text-ash group-hover:text-bone/60"
                    }`}
                  >
                    {r.kanji}
                  </span>
                  <span
                    className={`font-sans text-sm md:text-[15px] font-semibold tracking-wide whitespace-nowrap lg:whitespace-normal transition-colors duration-300 ${
                      isActive ? "text-bone" : "text-ash group-hover:text-bone"
                    }`}
                  >
                    {r.name}
                  </span>
                  {isActive && (
                    <motion.span
                      layoutId="role-glow"
                      className="absolute inset-0 rounded-xl border border-blood/60 pointer-events-none"
                      transition={{ duration: 0.4 }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* role panel */}
          <AnimatePresence mode="wait">
            <motion.div
              key={role.id}
              initial={{ opacity: 0, y: 24, filter: "blur(6px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -18, filter: "blur(6px)" }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="grid md:grid-cols-2 gap-5">
                {/* allowed */}
                <div className="rounded-2xl border border-blood/35 bg-gradient-to-b from-blood/12 to-transparent p-6 md:p-8">
                  <p className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-[0.25em] text-ember mb-6">
                    <Check className="size-4" />
                    Дозволено
                  </p>
                  <ul className="space-y-4">
                    {role.allowed.map((a, i) => (
                      <motion.li
                        key={a}
                        initial={{ opacity: 0, x: -12 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.06 * i, duration: 0.4 }}
                        className="flex gap-3 font-sans text-sm md:text-[15px] leading-relaxed text-bone/80"
                      >
                        <span className="mt-1 grid place-items-center size-5 shrink-0 rounded-full bg-blood/25 text-blood">
                          <Check className="size-3" />
                        </span>
                        {a}
                      </motion.li>
                    ))}
                  </ul>
                </div>

                {/* forbidden */}
                <div className="rounded-2xl border border-bone/12 bg-coal/60 p-6 md:p-8">
                  <p className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-[0.25em] text-ash mb-6">
                    <ShieldAlert className="size-4" />
                    Запрещено
                  </p>
                  <ul className="space-y-4">
                    {role.forbidden.map((f, i) => (
                      <motion.li
                        key={f}
                        initial={{ opacity: 0, x: -12 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.06 * i, duration: 0.4 }}
                        className="flex gap-3 font-sans text-sm md:text-[15px] leading-relaxed text-bone/65"
                      >
                        <span className="mt-1 grid place-items-center size-5 shrink-0 rounded-full bg-bone/10 text-ash">
                          <X className="size-3" />
                        </span>
                        {f}
                      </motion.li>
                    ))}
                  </ul>
                </div>
              </div>

              {role.note && (
                <motion.div
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25, duration: 0.5 }}
                  className="mt-5 flex items-start gap-3 rounded-xl border border-blood/25 bg-blood/8 p-5"
                >
                  <Info className="mt-0.5 size-4 shrink-0 text-blood" />
                  <p className="font-serif italic text-sm md:text-base text-bone/70 leading-relaxed">
                    {role.note}
                  </p>
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* squad inner hierarchy */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.7 }}
          className="mt-16 md:mt-24"
        >
          <p className="font-sans text-[11px] uppercase tracking-[0.4em] text-blood mb-6">
            Внутри отрядов
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {SQUAD.map((s, i) => (
              <motion.div
                key={s.rank}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.5 }}
                className="group rounded-xl border border-bone/10 bg-void/60 p-6 hover:border-blood/50 transition-colors duration-300"
              >
                <span className="font-display text-2xl font-black text-blood/30 group-hover:text-blood transition-colors duration-300 tabular-nums">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <p className="mt-3 font-display text-sm md:text-base font-bold uppercase text-bone">
                  {s.rank}
                </p>
                <p className="mt-2 font-sans text-xs md:text-sm leading-relaxed text-ash">
                  {s.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* glossary */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9 }}
          className="mt-10 grid md:grid-cols-2 gap-4"
        >
          <div className="rounded-xl border border-bone/10 bg-coal/50 p-6">
            <p className="font-display text-sm font-bold uppercase text-ember mb-2">
              Полное командование
            </p>
            <p className="font-sans text-xs md:text-sm leading-relaxed text-ash">
              Полная координация нижестоящих: тренировки, вылазки, задания любой
              сложности. При полном руководстве отрядом — изменения состава и
              полное командование его членами.
            </p>
          </div>
          <div className="rounded-xl border border-bone/10 bg-coal/50 p-6">
            <p className="font-display text-sm font-bold uppercase text-bone/70 mb-2">
              Руководить нижестоящими
            </p>
            <p className="font-sans text-xs md:text-sm leading-relaxed text-ash">
              Выдача мелких поручений, не подвергающих исполнителя сильной
              опасности.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
