import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export default function Cursor() {
  const [enabled, setEnabled] = useState(false);
  const [hovering, setHovering] = useState(false);
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 500, damping: 40 });
  const sy = useSpring(y, { stiffness: 500, damping: 40 });

  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    setEnabled(true);
    const move = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      const t = e.target as HTMLElement;
      setHovering(!!t.closest("a, button"));
    };
    window.addEventListener("mousemove", move, { passive: true });
    return () => window.removeEventListener("mousemove", move);
  }, [x, y]);

  if (!enabled) return null;

  return (
    <motion.div
      className="custom-cursor fixed top-0 left-0 z-[99] pointer-events-none mix-blend-difference"
      style={{ x: sx, y: sy }}
    >
      <motion.div
        animate={{ scale: hovering ? 2.4 : 1 }}
        transition={{ duration: 0.25 }}
        className="-translate-x-1/2 -translate-y-1/2 rounded-full border border-blood"
        style={{ width: 34, height: 34, background: hovering ? "rgba(211,19,42,0.15)" : "transparent" }}
      />
      <div className="absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 size-1.5 rounded-full bg-blood" />
    </motion.div>
  );
}
