import { motion } from "framer-motion";

export default function SectionHead({
  index,
  kanji,
  title,
  sub,
}: {
  index: string;
  kanji: string;
  title: string;
  sub?: string;
}) {
  return (
    <div className="relative mb-14 md:mb-20">
      <motion.span
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 0.12 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 1.2 }}
        className="pointer-events-none absolute -top-10 md:-top-16 -left-2 md:-left-6 font-display font-black text-blood select-none text-[22vw] md:text-[11rem] leading-none"
      >
        {kanji}
      </motion.span>

      <div className="relative">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="flex items-center gap-4 mb-5"
        >
          <span className="font-display text-blood text-sm md:text-base font-bold tracking-[0.3em]">
            {index}
          </span>
          <span className="h-px w-16 md:w-28 bg-gradient-to-r from-blood to-transparent" />
        </motion.div>

        <h2 className="overflow-hidden">
          <motion.span
            initial={{ y: "110%" }}
            whileInView={{ y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
            className="block font-display font-extrabold uppercase text-3xl md:text-6xl tracking-tight text-bone"
          >
            {title}
          </motion.span>
        </h2>

        {sub && (
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ delay: 0.25, duration: 0.8 }}
            className="mt-5 max-w-2xl font-serif italic text-lg md:text-2xl text-ash leading-relaxed"
          >
            {sub}
          </motion.p>
        )}
      </div>
    </div>
  );
}
