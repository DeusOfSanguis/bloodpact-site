import { motion } from "framer-motion";
import { Eye, Crown, AlertTriangle } from "lucide-react";
import SectionHead from "./SectionHead";

const ROMAN = ["I", "II", "III", "IV", "V", "VI"];

function MoonColumn({
  title,
  kanji,
  upper,
}: {
  title: string;
  kanji: string;
  upper: boolean;
}) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl border p-6 md:p-10 ${
        upper
          ? "border-blood/40 bg-gradient-to-b from-blood/15 via-coal to-coal blood-glow"
          : "border-bone/12 bg-coal/60"
      }`}
    >
      <span
        className={`pointer-events-none absolute -top-8 right-4 font-display font-black text-[9rem] leading-none select-none ${
          upper ? "text-blood/15" : "text-bone/5"
        }`}
      >
        {kanji}
      </span>

      <div className="relative flex items-center gap-3 mb-8">
        {upper && <Crown className="size-5 text-blood" />}
        <div>
          <h3 className="font-display text-xl md:text-2xl font-bold uppercase text-bone">
            {title}
          </h3>
          <p className="mt-1 font-serif italic text-sm text-ash">
            {upper
              ? "Надпись «высшая» выгравирована во втором глазу"
              : "Число выгравировано в одном глазу"}
          </p>
        </div>
      </div>

      <div className="relative space-y-2">
        {ROMAN.map((r, i) => (
          <motion.div
            key={r}
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ delay: i * 0.06, duration: 0.5 }}
            className={`group flex items-center justify-between rounded-lg border px-4 py-3.5 transition-all duration-300 ${
              upper
                ? "border-blood/25 hover:border-blood hover:bg-blood/10"
                : "border-bone/10 hover:border-bone/40 hover:bg-bone/5"
            }`}
          >
            <div className="flex items-center gap-4">
              <span
                className={`font-display text-lg md:text-xl font-bold tabular-nums ${
                  upper ? "text-blood" : "text-bone/60"
                }`}
              >
                {r}
              </span>
              <span className="font-sans text-sm md:text-base text-bone/80">
                {upper ? "Высшая луна" : "Низшая луна"} · {i + 1}
              </span>
            </div>
            <span className="relative flex items-center gap-1.5">
              <Eye
                className={`size-4 transition-all duration-300 group-hover:scale-125 ${
                  upper ? "text-blood" : "text-ash"
                }`}
              />
              {upper && <Eye className="size-4 text-blood/50 transition-all duration-300 group-hover:scale-110" />}
            </span>
          </motion.div>
        ))}
      </div>

      <p className="relative mt-6 font-sans text-xs md:text-sm leading-relaxed text-ash">
        {upper
          ? "Первая высшая — сильнейший демон после Прародителя. Подчинение между лунами определяется их каноничными характерами."
          : "Шестая низшая — слабейшая из двенадцати. Любой приказ высшей луны для низшей абсолютен."}
      </p>
    </div>
  );
}

export default function Moons() {
  return (
    <section id="moons" className="relative px-5 md:px-10 py-24 md:py-40 overflow-hidden">
      {/* ambient glow */}
      <div className="pointer-events-none absolute top-1/3 left-1/2 -translate-x-1/2 size-[800px] rounded-full bg-blood/10 blur-[160px] animate-pulse-slow" />

      <div className="relative mx-auto max-w-[1300px]">
        <SectionHead
          index="03"
          kanji="月"
          title="Двенадцать лун"
          sub="Группа сильнейших демонов, получивших кровь от самого Прародителя. Каждая капля умножает их демоническую силу."
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.7 }}
          className="mb-10 flex items-start gap-4 rounded-xl border border-blood/30 bg-blood/10 p-5 md:p-6 max-w-3xl"
        >
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-blood" />
          <p className="font-sans text-sm md:text-base leading-relaxed text-bone/80">
            Ранг луны выгравирован прямо на глазах: у низших — лишь число в
            одном глазу, у высших второй глаз несёт надпись{" "}
            <span className="text-ember font-semibold">«высшая»</span>.
            Нумерация идёт от сильнейшей — <span className="text-bone font-semibold">I Высшая</span> — к
            слабейшей — <span className="text-bone font-semibold">VI Низшая</span>.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 md:gap-8">
          <MoonColumn title="Высшие луны" kanji="上" upper />
          <MoonColumn title="Низшие луны" kanji="下" upper={false} />
        </div>
      </div>
    </section>
  );
}
