import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Flame,
  ScrollText,
  ShieldCheck,
  Target,
  Skull,
  Scale,
  Award,
  Plus,
} from "lucide-react";
import SectionHead from "./SectionHead";

type Def = {
  icon: typeof Flame;
  title: string;
  short: string;
  points: string[];
  note?: string;
};

const DEFS: Def[] = [
  {
    icon: Flame,
    title: "Техника демонической крови",
    short: "Уникальные боевые техники высших хищников ночи",
    points: [
      "Боевые техники, доступные демонам, съевшим достаточное количество людей.",
      "Чем больше крови поглощено — тем разрушительнее и изощрённее техника.",
    ],
  },
  {
    icon: ScrollText,
    title: "Этикет демонов",
    short: "Свод правил поведения внутри фракции",
    points: [
      "При виде демона Двенадцати Лун или Прародителя — склони голову и встань на колено. Оставайся в этой позе, пока не разрешат подняться.",
      "Общение со старшими по рангу — сдержанное и уважительное.",
      "Запрещено общаться с лунами или Прародителем по-свойски, товарищески.",
    ],
    note: "Исключение из правила коленопреклонения — активный бой.",
  },
  {
    icon: ShieldCheck,
    title: "Обязанности демонов",
    short: "Набор задач, ответственностей и действий",
    points: [
      "Слушать и выполнять приказы старших по рангу.",
      "Нести ответственность за свои поступки и нарушения.",
    ],
  },
  {
    icon: Target,
    title: "Цели существования",
    short: "Долг демонов перед Прародителем",
    points: [
      "Поиск голубой паучьей лилии.",
      "Истребление членов семейства Убуяшики.",
    ],
  },
  {
    icon: Skull,
    title: "Проклятье демонической крови",
    short: "Способность Прародителя контролировать демонов",
    points: [
      "Под страхом мучительной смерти запрещено произносить имя и фамилию Господина, а также любую информацию, способную привести к Прародителю или нарушить его планы.",
      "Ни один демон не имеет права ослушаться приказа Господина.",
    ],
  },
  {
    icon: Scale,
    title: "Демонический закон",
    short: "Свод правил и норм жизни фракции",
    points: [
      "Регламентирует все аспекты жизни во фракции.",
      "Исполнение обязательно для каждого демона — нарушение наказуемо.",
    ],
  },
  {
    icon: Award,
    title: "Шрамы",
    short: "Достижения, отмеченные кровью",
    points: [
      "За шрамы положено повышение по рангу.",
      "За шрамы выдаётся денежное вознаграждение.",
    ],
  },
];

export default function Definitions() {
  const [open, setOpen] = useState<number | null>(1);

  return (
    <section id="laws" className="relative px-5 md:px-10 py-24 md:py-40 bg-coal/30">
      <div className="mx-auto max-w-[1200px]">
        <SectionHead
          index="02"
          kanji="法"
          title="Основные определения"
          sub="Семь понятий, на которых держится устройство фракции. Коснись, чтобы раскрыть."
        />

        <div className="border-t border-bone/10">
          {DEFS.map((d, i) => {
            const isOpen = open === i;
            return (
              <motion.div
                key={d.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ delay: i * 0.05, duration: 0.55 }}
                className="border-b border-bone/10"
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="group w-full flex items-center gap-5 md:gap-8 py-6 md:py-7 text-left"
                >
                  <span
                    className={`font-display text-sm md:text-base font-bold tabular-nums transition-colors duration-300 ${
                      isOpen ? "text-blood" : "text-ash"
                    }`}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <d.icon
                    className={`size-5 md:size-6 shrink-0 transition-colors duration-300 ${
                      isOpen ? "text-blood" : "text-ash group-hover:text-bone"
                    }`}
                  />
                  <span className="flex-1">
                    <span
                      className={`block font-display font-bold uppercase tracking-wide text-base md:text-2xl transition-colors duration-300 ${
                        isOpen ? "text-bone" : "text-bone/70 group-hover:text-bone"
                      }`}
                    >
                      {d.title}
                    </span>
                    <span className="mt-1 hidden md:block font-serif italic text-sm text-ash">
                      {d.short}
                    </span>
                  </span>
                  <motion.span
                    animate={{ rotate: isOpen ? 45 : 0 }}
                    transition={{ duration: 0.35 }}
                    className={`grid place-items-center size-9 md:size-11 rounded-full border transition-colors duration-300 ${
                      isOpen
                        ? "border-blood bg-blood text-bone"
                        : "border-bone/20 text-ash group-hover:border-blood/60"
                    }`}
                  >
                    <Plus className="size-4" />
                  </motion.span>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <div className="pb-8 pl-[3.4rem] md:pl-[6.5rem] pr-4 max-w-3xl">
                        <ul className="space-y-3">
                          {d.points.map((p, j) => (
                            <motion.li
                              key={j}
                              initial={{ opacity: 0, x: -14 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: 0.1 + j * 0.07, duration: 0.4 }}
                              className="flex gap-3 font-sans text-sm md:text-base leading-relaxed text-bone/75"
                            >
                              <span className="mt-2 size-1.5 shrink-0 rounded-full bg-blood" />
                              {p}
                            </motion.li>
                          ))}
                        </ul>
                        {d.note && (
                          <p className="mt-4 rounded-lg border border-blood/30 bg-blood/10 px-4 py-3 font-sans text-xs md:text-sm text-ember">
                            {d.note}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
